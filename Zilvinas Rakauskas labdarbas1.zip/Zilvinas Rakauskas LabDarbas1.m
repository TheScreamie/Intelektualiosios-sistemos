%Classification using perceptron
clc 
clear all
close all
%Reading apple images
A1=imread('apple_04.jpg');
A2=imread('apple_05.jpg');
A3=imread('apple_06.jpg');
A4=imread('apple_07.jpg');
A5=imread('apple_11.jpg');
A6=imread('apple_12.jpg');
A7=imread('apple_13.jpg');
A8=imread('apple_17.jpg');
A9=imread('apple_19.jpg');

%Reading pears images
P1=imread('pear_01.jpg');
P2=imread('pear_02.jpg');
P3=imread('pear_03.jpg');
P4=imread('pear_09.jpg');

%Calculate for each image, colour and roundness
%For Apples
%1st apple image(A1)
hsv_value_A1=spalva_color(A1); %color
metric_A1=apvalumas_roundness(A1); %roundness
%2nd apple image(A2)
hsv_value_A2=spalva_color(A2); %color
metric_A2=apvalumas_roundness(A2); %roundness
%3rd apple image(A3)
hsv_value_A3=spalva_color(A3); %color
metric_A3=apvalumas_roundness(A3); %roundness
%4th apple image(A4)
hsv_value_A4=spalva_color(A4); %color
metric_A4=apvalumas_roundness(A4); %roundness
%5th apple image(A5)
hsv_value_A5=spalva_color(A5); %color
metric_A5=apvalumas_roundness(A5); %roundness
%6th apple image(A6)
hsv_value_A6=spalva_color(A6); %color
metric_A6=apvalumas_roundness(A6); %roundness
%7th apple image(A7)
hsv_value_A7=spalva_color(A7); %color
metric_A7=apvalumas_roundness(A7); %roundness
%8th apple image(A8)
hsv_value_A8=spalva_color(A8); %color
metric_A8=apvalumas_roundness(A8); %roundness
%9th apple image(A9)
hsv_value_A9=spalva_color(A9); %color
metric_A9=apvalumas_roundness(A9); %roundness

%For Pears
%1st pear image(P1)
hsv_value_P1=spalva_color(P1); %color
metric_P1=apvalumas_roundness(P1); %roundness
%2nd pear image(P2)
hsv_value_P2=spalva_color(P2); %color
metric_P2=apvalumas_roundness(P2); %roundness
%3rd pear image(P3)
hsv_value_P3=spalva_color(P3); %color
metric_P3=apvalumas_roundness(P3); %roundness
%2nd pear image(P4)
hsv_value_P4=spalva_color(P4); %color
metric_P4=apvalumas_roundness(P4); %roundness

%selecting features(color, roundness, 3 apples and 2 pears)
%A1,A2,A3,P1,P2
%building matrix 2x5
x1=[hsv_value_A1 hsv_value_A2 hsv_value_A3 hsv_value_P1 hsv_value_P2];
x2=[metric_A1 metric_A2 metric_A3 metric_P1 metric_P2];
% estimated features are stored in matrix P:
P=[x1;x2];
e_n=zeros(1,5);

%Desired output vector
T=[1;1;1;-1;-1];

%% train single perceptron with two inputs and one output

% generate random initial values of w1, w2 and b
w1 = randn(1);
w2 = randn(1);
b = randn(1);

% calculate wieghted sum with randomly generated parameters
%v1 = <...>; % write your code here
v = x1(1)*w1+x2(1)*w2+b;
% calculate current output of the perceptron 
if v > 0
	y = 1;
else
	y = -1;
end
% calculate the error
e1 = T(1) - y;

% repeat the same for the rest 4 inputs x1 and x2
% calculate wieghted sum with randomly generated parameters
% v2 = <...> ; % write your code here
v = x1(2)*w1+x2(2)*w2+b;
% calculate current output of the perceptron 
if v > 0
	y = 1;
else
	y = -1;
end
% calculate the error
e2 = T(2) - y;

% <...> write the code for another 3 inputs

v = x1(3)*w1+x2(3)*w2+b;
if v > 0
	y = 1;
else
	y = -1;
end
e3 = T(3) - y;

v = x1(4)*w1+x2(4)*w2+b;
if v > 0
	y = 1;
else
	y = -1;
end
e4 = T(4) - y;

v = x1(5)*w1+x2(5)*w2+b;
if v > 0
	y = 1;
else
	y = -1;
end
e5 = T(5) - y;


% calculate the total error for these 5 inputs 
e = abs(e1) + abs(e2) + abs(e3) + abs(e4) + abs(e5);

eta = 0.01;
count = 0;
%training algorithm
while e ~= 0 % executes while the total error is not 0

    for i = 1:1:5       %koeficientu atnaujinimo ciklas
        v = x1(i)*w1+x2(i)*w2+b;
        if v > 0        %skaiciuojam tinklo atsaka
	        y = 1;
        else
	        y = -1;
        end
%   calculate error for current example
        e = T(i) - y;
%   update parameters using current inputs ant current error
 	    w1 = w1+eta*e*x1(i);
        w2 = w2+eta*e*x2(i);
        b = b+eta*e;
    end

    for i = 1:1:5
        v = x1(i)*w1+x2(i)*w2 + b;
        if v > 0
            y = 1;
        else
            y = -1;
        end
        e_n(i) = T(i)-y;
    end
    e = abs(e_n(1)) + abs(e_n(2)) + abs(e_n(3)) + abs(e_n(4)) + abs(e_n(5));
    count = count + 1;
end

%tinklo testavimas
x_test1=[hsv_value_A5 hsv_value_P3 hsv_value_A6 hsv_value_P4 hsv_value_A7];
x_test2=[metric_A5 metric_P3 metric_A6 metric_P4 metric_A7];
P_test=[x_test1;x_test2];
T_test=[1;-1;1;-1;1];

for i = 1:1:5
        v = x_test1(i)*w1+x_test2(i)*w2 + b;
        if v > 0
            y = 1;
        else
            y = -1;
        end
        if T_test(i) == 1
        ats1='obuolys';
        else
        ats1='kriause';
        end
        if y == 1
        ats2='obuolys';
        else
        ats2='kriause';
        end
        fprintf('%d paveikslelis (tikra verte: %s) tinklo  atsakas: %s \n', i, ats1, ats2)    
end

fprintf('Mokymosi iteracijos: %d.\n', count)


%Naive Bayes Classifier

%pakartojami mokinimosi duomenys
x1 = [hsv_value_A1, hsv_value_A2, hsv_value_A3, hsv_value_P1, hsv_value_P2];
x2 = [metric_A1, metric_A2, metric_A3, metric_P1, metric_P2];
P = [x1; x2];

%Mokinimosi teisingos vertes (klases). 1: obuolys, -1: kriause
T = [1, 1, 1, -1, -1]; 

% Isskyrimas duomenu klasemis
apple_class = P(:, T == 1);
pear_class = P(:, T == -1);

% Calculate priors
P_apple_class = size(apple_class, 2) / size(P, 2);          % P(T=1), proportion of class 1 examples
P_pear_class = size(pear_class, 2) / size(P, 2);  % P(T=-1), proportion of class -1 examples

% Calculate mean and variance for Gaussian likelihood for each class
mean_apple_class = mean(apple_class , 2);        % Mean of each feature for T=1 (column vector)
mean_pear_class = mean(pear_class, 2);% Mean of each feature for T=-1 (column vector)
var_apple_class = var(apple_class , 0, 2);       % Variance of each feature for T=1 (column vector)
var_pear_class = var(pear_class, 0, 2);% Variance of each feature for T=-1 (column vector)

% Function to calculate Gaussian likelihood
function likelihood = gaussian_likelihood(x, mean_val, var_val)
    % Element-wise Gaussian likelihood calculation
    likelihood = (1 ./ sqrt(2 * pi * var_val)) .* exp(-((x - mean_val).^2) ./ (2 * var_val));
end

% Function to calculate posterior probability
function posterior = calculate_posterior(x, mean_val, var_val, prior)
    likelihood = gaussian_likelihood(x, mean_val, var_val);
    posterior = prod(likelihood) * prior;
end

% Function to classify a new point
function predicted_class = classify(x_new, mean_apple_class, var_apple_class, P_apple_class, mean_pear_class, var_pear_class, P_pear_class)
    % Ensure the new point is a column vector
    x_new = reshape(x_new, [], 1);  % Ensure x_new is a column vector

    % Calculate posteriors for both classes
    posterior_apple_class = calculate_posterior(x_new, mean_apple_class, var_apple_class, P_apple_class);
    posterior_pear_class = calculate_posterior(x_new, mean_pear_class, var_pear_class, P_pear_class);
    
    % Compare posteriors and classify
    if posterior_apple_class > posterior_pear_class
        predicted_class = 1;
    else
        predicted_class = -1;
    end
end


% Test data (replace hsv and metric values with actual data)
x1_test_bayes = [hsv_value_P1,hsv_value_A2,hsv_value_P2,hsv_value_A4, hsv_value_A5, hsv_value_P3, hsv_value_A6, hsv_value_P4, hsv_value_A7, hsv_value_A8, hsv_value_A9];  % HSV values
x2_test_bayes = [metric_P1,metric_A2,metric_P2,metric_A4, metric_A5, metric_P3, metric_A6, metric_P4, metric_A7, metric_A8, metric_A9];  % Metric values

% Form the test feature matrix (each column is a data point)
P_test_bayes = [x1_test_bayes; x2_test_bayes];  % Two rows: HSV (x1) and Metric (x2)

% Loop over each test point (each column in P_test_bayes)
for i = 1:size(P_test_bayes, 2)
    % Extract the current test point (i-th column)
    x_new = P_test_bayes(:, i);
    
    % Classify the new point
    predicted_class = classify(x_new, mean_apple_class, var_apple_class, P_apple_class, mean_pear_class, var_pear_class, P_pear_class);
    
    % Display the predicted class
    fprintf('Predicted class for test point %d: %d\n', i, predicted_class);
end
